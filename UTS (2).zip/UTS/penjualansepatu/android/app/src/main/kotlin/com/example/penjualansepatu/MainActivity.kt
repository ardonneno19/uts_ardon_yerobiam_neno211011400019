package com.example.penjualansepatu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
